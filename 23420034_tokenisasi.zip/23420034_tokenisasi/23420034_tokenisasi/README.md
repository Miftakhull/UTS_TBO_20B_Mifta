# 23420037_tokenization
Simple Tokenization in HTML and JavaScript.

# UTS Teori Bahasa Formal dan Otomata

Nama      : Miftakhul Choir.</br>
NIM       : 23420037</br>
Prodi     : Teknik Informatika</br>
Angkatan  : 2020 Malam</br>
